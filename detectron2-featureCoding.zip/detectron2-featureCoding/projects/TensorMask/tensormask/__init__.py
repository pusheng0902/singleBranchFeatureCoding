# Copyright (c) Facebook, Inc. and its affiliates.
from .config import add_tensormask_config
from .arch import TensorMask
